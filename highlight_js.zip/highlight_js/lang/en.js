﻿CKEDITOR.plugins.setLang('highlight_js', 'en',
{
	highlight:
	{
		title: 'Add or update a code snippet',
		dialogTitle: 'Insert code',
		selectLabel: 'Select code language'
	}
});
