CKEDITOR.plugins.setLang('highlight_js', 'ru',
{
    highlight:
    {
        title: 'Вставка или обновление кода',
        dialogTitle: 'Вставка кода',
        selectLabel: 'Выберите язык разметки'
    }
});